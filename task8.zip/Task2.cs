﻿using System;

namespace Task2
{
    public class PrimitiveArrays
    {
        public static int[] InitializeArray(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = i + 1; // Заповнюємо масив числами від 1 до size
            }
            return array;
        }

        public static void PrintArray(int[] numbers)
        {
            // Об'єднуємо елементи масиву в один рядок, розділений пробілами
            string output = string.Join(" ", numbers);
            Console.Write(output); // Використовуємо Console.Write, щоб не додавати новий рядок
        }


        public static int SumArray(int[] array)
        {
            int sum = 0;
            foreach (var number in array)
            {
                sum += number;
            }
            return sum;
        }
    }
}
