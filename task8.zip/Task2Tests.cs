﻿using Microsoft.VisualStudio.TestTools.UnitTesting; // Переконайтеся, що цей рядок присутній
using System.IO;
using System; 


namespace Task2.Tests
{
    [TestClass]
    public class Task2Tests
    {
        [TestMethod]
        public void TestInitializeArray()
        {
            int size = 5;
            int[] expectedArray = { 1, 2, 3, 4, 5 };
            int[] actualArray = PrimitiveArrays.InitializeArray(size);
            CollectionAssert.AreEqual(expectedArray, actualArray);
        }

        [TestMethod]
        public void TestPrintArray()
        {
            int[] numbers = { 1, 2, 3, 4, 5 };
            string expectedOutput = "1 2 3 4 5"; // Очікуваний вивід

            using (var sw = new StringWriter())
            {
                Console.SetOut(sw); // Перенаправлення виводу на StringWriter
                PrimitiveArrays.PrintArray(numbers); // Виклик методу
                var result = sw.ToString().Trim(); // Отримати вивід та видалити пробіли по краях

                // Порівняти очікуваний та фактичний вивід
                Assert.AreEqual(expectedOutput, result);
            }
        }

        [TestMethod]
        public void TestSumArray()
        {
            int[] numbers = { 1, 2, 3, 4, 5 };
            int expectedSum = 15;
            int actualSum = PrimitiveArrays.SumArray(numbers);
            Assert.AreEqual(expectedSum, actualSum);
        }

        [TestMethod]
        [DataRow(1, 1)]
        [DataRow(2, 3)]
        [DataRow(3, 6)]
        public void TestSumArrayWithParameters(int size, int expectedSum)
        {
            int[] numbers = PrimitiveArrays.InitializeArray(size);
            int actualSum = PrimitiveArrays.SumArray(numbers);
            Assert.AreEqual(expectedSum, actualSum);
        }
    }
}
