﻿using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using log4net;
using System;
using System.IO;

public class CustomTestListener : ITestListener
{
    private static readonly ILog log = LogManager.GetLogger(typeof(CustomTestListener));
    private IWebDriver driver;

    public void TestStarted(ITest test)
    {
        log.Info($"Тест начат: {test.Name}");
        StartBrowser();
    }

    public void TestFinished(ITestResult result)
    {
        log.Info($"Тест завершён: {result.Name}, Статус: {result.ResultState}");
        if (result.ResultState == ResultState.Failure)
        {
            SaveHtmlOnFailure(result);
        }
        CloseBrowser();
    }

    public void TestOutput(TestOutput output)
    {
        log.Info($"Вывод теста: {output.Text}");
    }

    public void SendMessage(TestMessage message)
    {
        log.Info($"Сообщение: {message.Message}");
    }

    private void StartBrowser()
    {
        log.Info("Запуск браузера...");
        driver = new ChromeDriver();
        driver.Navigate().GoToUrl("https://demoqa.com");
    }

    private void SaveHtmlOnFailure(ITestResult result)
    {
        log.Error("Сохранение HTML при ошибке...");
        string fileName = $"{result.Name}_{Guid.NewGuid()}_{DateTime.Now:yyyyMMddHHmmss}.html";
        File.WriteAllText(Path.Combine("ErrorLogs", fileName), driver.PageSource);
        log.Error($"HTML сохранено в файл: {fileName}");
    }

    private void CloseBrowser()
    {
        log.Info("Закрытие браузера...");
        driver?.Quit();
    }
}
