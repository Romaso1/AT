﻿using MySql.Data.MySqlClient;
using System;

public class DatabaseManager
{
    private string connectionString = "Server=localhost;Database=TestResults;User ID=root;Password=Kill1234;";

    public void InsertTestResult(string testName, string status, DateTime startTime, DateTime endTime, string logMessage)
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            connection.Open();
            var query = "INSERT INTO TestExecutionLogs (TestName, Status, StartTime, EndTime, LogMessage) " +
                        "VALUES (@TestName, @Status, @StartTime, @EndTime, @LogMessage)";
            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@TestName", testName);
                command.Parameters.AddWithValue("@Status", status);
                command.Parameters.AddWithValue("@StartTime", startTime);
                command.Parameters.AddWithValue("@EndTime", endTime);
                command.Parameters.AddWithValue("@LogMessage", logMessage);
                command.ExecuteNonQuery();
            }
        }
    }
}
