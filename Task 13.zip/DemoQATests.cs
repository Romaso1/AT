﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

[TestFixture]
public class DemoQATests
{
    private IWebDriver driver;

    [SetUp]
    public void SetUp()
    {
        driver = new ChromeDriver();
    }

    [Test]
    public void TestExample()
    {
        driver.Navigate().GoToUrl("https://demoqa.com");
        Assert.That(driver.Title.Contains("ToolsQA"), Is.True);
    }

    [TearDown]
    public void TearDown()
    {
        driver?.Quit();
    }
}
