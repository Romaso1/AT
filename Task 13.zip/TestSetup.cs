﻿using log4net;
using log4net.Config;
using NUnit.Framework;
using System.IO; // Добавлено пространство имен

[SetUpFixture]
public class TestSetup
{
    [OneTimeSetUp]
    public void GlobalSetup()
    {
        XmlConfigurator.Configure(new FileInfo("log4net.config"));
    }
}
