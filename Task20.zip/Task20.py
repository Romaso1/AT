from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def setup_driver(platform):
    """Setup Appium driver for Android or iOS."""
    if platform == "Android":
        desired_caps = {
            "platformName": "Android",
            "deviceName": "Pixel_4_API_30",
            "automationName": "UiAutomator2",
            "appPackage": "com.android.calculator2",
            "appActivity": "com.android.calculator2.Calculator"
        }
    elif platform == "iOS":
        desired_caps = {
            "platformName": "iOS",
            "deviceName": "iPhone 14",
            "automationName": "XCUITest",
            "bundleId": "com.apple.calculator"
        }
    else:
        raise ValueError("Invalid platform! Choose 'Android' or 'iOS'.")

    driver = webdriver.Remote("http://localhost:4723/wd/hub", desired_caps)
    return driver

def capture_screenshot(driver, name):
    """Capture a screenshot."""
    driver.save_screenshot(f"{name}.png")

def capture_dom(driver, name):
    """Capture the DOM structure."""
    with open(f"{name}.xml", "w") as file:
        file.write(driver.page_source)

def test_division_by_zero(platform):
    """Test division by zero in the calculator app."""
    driver = setup_driver(platform)
    try:
        wait = WebDriverWait(driver, 10)

        # Find elements for calculator buttons
        if platform == "Android":
            num_1 = wait.until(EC.presence_of_element_located((By.ID, "digit_1")))
            divide = wait.until(EC.presence_of_element_located((By.ID, "op_div")))
            zero = wait.until(EC.presence_of_element_located((By.ID, "digit_0")))
            equals = wait.until(EC.presence_of_element_located((By.ID, "eq")))
            result_field = driver.find_element(By.ID, "result")
        elif platform == "iOS":
            num_1 = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "1")))
            divide = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "divide")))
            zero = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "0")))
            equals = wait.until(EC.presence_of_element_located((By.ACCESSIBILITY_ID, "equals")))
            result_field = driver.find_element(By.ACCESSIBILITY_ID, "result")

        # Perform operation: 1 / 0
        num_1.click()
        divide.click()
        zero.click()
        equals.click()

        # Capture screenshot and DOM
        capture_screenshot(driver, f"{platform}_division_by_zero")
        capture_dom(driver, f"{platform}_division_by_zero")

        # Verify the result
        error_message = result_field.text
        assert "Cannot divide by zero" in error_message or "Error" in error_message, \
            "The calculator did not display the correct error message!"

        print("Test passed: Division by zero error displayed correctly.")
    except Exception as e:
        print(f"Test failed: {e}")
        capture_screenshot(driver, f"{platform}_failure")
        capture_dom(driver, f"{platform}_failure")
    finally:
        driver.quit()

# Run the test for Android or iOS
if __name__ == "__main__":
    test_division_by_zero(platform="Android")  # Change to "iOS" for iOS testing
