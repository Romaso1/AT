﻿namespace TrelloAPITests.Models
{
    public class OrganizationResponse
    {
        public string Id { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
    }
}
