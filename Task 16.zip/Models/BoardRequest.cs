﻿namespace TrelloAPITests.Models
{
    public class OrganizationRequest
    {
        public string DisplayName { get; set; } = string.Empty;
        public string Key { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;

        public OrganizationRequest(string displayName, string key, string token)
        {
            DisplayName = displayName;
            Key = key;
            Token = token;
        }
    }
}
