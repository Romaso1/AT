﻿namespace TrelloAPITests.Models
{
    public class BoardResponse
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}
