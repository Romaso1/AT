﻿namespace TrelloAPITests.Models
{
    public class BoardRequest
    {
        public string Name { get; set; } = string.Empty;
        public string IdOrganization { get; set; } = string.Empty;
        public string Key { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;

        public BoardRequest(string name, string idOrganization, string key, string token)
        {
            Name = name;
            IdOrganization = idOrganization;
            Key = key;
            Token = token;
        }
    }
}
