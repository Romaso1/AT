﻿using NUnit.Framework;
using RestSharp;
using TrelloAPITests.Models;
using TrelloAPITests.Comparators;

namespace TrelloAPITests.Tests
{
    public class TrelloApiTests
    {
        private const string ApiKey = "d8eb5d485dc1695cb02213103ced5dfd";
        private const string Token = "783112a45adfc75fc9ad37e9012b81c9b24f9f777e402463a686fb3f67f44604";
        private string organizationId = string.Empty;
        private string boardId = string.Empty;

        [Test]
        public void CreateOrganizationTest()
        {
            var requestBody = new OrganizationRequest("MyOrganization", ApiKey, Token);

            var client = new RestClient("https://api.trello.com/1/organizations");
            var request = new RestRequest()
            {
                Method = Method.Post
            }.AddJsonBody(requestBody);

            var response = client.Execute<OrganizationResponse>(request);

            Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.OK));
            Assert.That(response.Data, Is.Not.Null);

            organizationId = response.Data?.Id ?? string.Empty;
        }

        [Test]
        public void CreateBoardTest()
        {
            Assert.That(organizationId, Is.Not.Empty);

            var requestBody = new BoardRequest("MyBoard", organizationId, ApiKey, Token);

            var client = new RestClient("https://api.trello.com/1/boards");
            var request = new RestRequest()
            {
                Method = Method.Post
            }.AddJsonBody(requestBody);

            var response = client.Execute<BoardResponse>(request);

            Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.OK));
            Assert.That(response.Data, Is.Not.Null);

            boardId = response.Data?.Id ?? string.Empty;
        }

        [Test]
        public void ArchiveBoardTest()
        {
            Assert.That(boardId, Is.Not.Empty);

            var client = new RestClient($"https://api.trello.com/1/boards/{boardId}/closed");
            var request = new RestRequest()
            {
                Method = Method.Put
            }
            .AddQueryParameter("value", "true")
            .AddQueryParameter("key", ApiKey)
            .AddQueryParameter("token", Token);

            var response = client.Execute(request);

            Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.OK));
        }
    }
}
