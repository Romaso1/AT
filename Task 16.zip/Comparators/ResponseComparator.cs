﻿using TrelloAPITests.Models;

namespace TrelloAPITests.Comparators
{
    public static class ResponseComparator
    {
        public static bool CompareOrganizations(OrganizationResponse expected, OrganizationResponse actual)
        {
            return expected.Id == actual.Id && expected.DisplayName == actual.DisplayName;
        }

        public static bool CompareBoards(BoardResponse expected, BoardResponse actual)
        {
            return expected.Id == actual.Id && expected.Name == actual.Name;
        }
    }
}
