﻿using OpenQA.Selenium;
using System;

namespace Task_12
{
    public class WebElementWrapper
    {
        private IWebElement element;

        public WebElementWrapper(IWebElement element)
        {
            this.element = element;
        }

        public void Click()
        {
            Console.WriteLine($"Clicking on element: {element.Text}");
            element.Click();
        }

        public bool IsSelected()
        {
            bool isSelected = element.Selected;
            Console.WriteLine($"Element selected: {isSelected}");
            return isSelected;
        }
    }
}