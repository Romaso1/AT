﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace Task_12
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://demoqa.com/radio-button");

            RadioButtonPage radioButtonPage = new RadioButtonPage(driver);

            radioButtonPage.SelectYes();
            radioButtonPage.SelectImpressive();
            radioButtonPage.DeselectNo();

            driver.Quit();

            // Ожидание ввода перед закрытием консоли
            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        }
    }
}