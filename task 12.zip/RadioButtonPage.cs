﻿using OpenQA.Selenium;
using System;

namespace Task_12
{
    public class RadioButtonPage : BasePage
    {
        private IWebElement yesRadioButton => driver.FindElement(By.Id("yesRadio"));
        private IWebElement impressiveRadioButton => driver.FindElement(By.Id("impressiveRadio"));
        private IWebElement noRadioButton => driver.FindElement(By.Id("noRadio"));

        public RadioButtonPage(IWebDriver driver) : base(driver) { }

        public void SelectYes()
        {
            var yesLabel = driver.FindElement(By.XPath("//label[@for='yesRadio']"));
            if (!yesRadioButton.Selected)
            {
                Console.WriteLine("Selecting Yes Radio Button");
                yesLabel.Click();
            }
            else
            {
                Console.WriteLine("Yes Radio Button is already selected.");
            }
        }

        public void SelectImpressive()
        {
            var impressiveLabel = driver.FindElement(By.XPath("//label[@for='impressiveRadio']"));
            if (!impressiveRadioButton.Selected)
            {
                Console.WriteLine("Selecting Impressive Radio Button");
                impressiveLabel.Click();
            }
            else
            {
                Console.WriteLine("Impressive Radio Button is already selected.");
            }
        }

        public void DeselectNo()
        {
            if (noRadioButton.Selected)
            {
                Console.WriteLine("Deselecting No Radio Button");
                noRadioButton.Click();
            }
            else
            {
                Console.WriteLine("No Radio Button is already deselected.");
            }
        }
    }
}