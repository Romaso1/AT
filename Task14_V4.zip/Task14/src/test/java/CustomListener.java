
import io.qameta.allure.Attachment;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IExecutionListener;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class CustomListener implements ITestListener, ISuiteListener, IExecutionListener, IInvokedMethodListener {

    private static final Logger logger = Logger.getLogger(CustomListener.class);

    static {
        // Завантаження конфігурації log4j з файлу (переконайтеся, що log4j.properties знаходиться у src/test/resources або у корені проекту)
        PropertyConfigurator.configure("log4j.properties");
    }

    // ITestListener методи

    @Override
    public void onStart(ITestContext context) {
        logger.info("onStart(ITestContext): Завантаження тестових даних з локальної БД та запуск браузера.");
        // Наприклад: TestData.loadFromDB();
    }

    @Override
    public void onTestStart(ITestResult result) {
        logger.info("onTestStart: Тест " + result.getName() + " починається.");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("onTestSuccess: Тест " + result.getName() + " пройшов успішно.");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("onTestFailure: Тест " + result.getName() + " провалено. Виконується збереження артефактів.");

        // Отримання WebDriver з тестового контексту (встановлюємо його у тестах через context.setAttribute("WebDriver", driver))
        Object driverObj = result.getTestContext().getAttribute("WebDriver");
        if (driverObj instanceof WebDriver) {
            WebDriver driver = (WebDriver) driverObj;
            // Прикріплення знімку екрану та HTML до звіту Allure
            saveScreenshotPNG(driver);
            savePageSource(driver);
        }

        // Збереження HTML сторінки у файл
        String testName = result.getName();
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String uniqueId = UUID.randomUUID().toString().substring(0, 8);
        String fileName = testName + "_" + uniqueId + "_" + timestamp + ".html";

        File dir = new File("failures");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try (FileWriter fw = new FileWriter(new File(dir, fileName))) {
            String pageSource = (driverObj instanceof WebDriver) ? ((WebDriver) driverObj).getPageSource() : "<html><body>No Source</body></html>";
            fw.write(pageSource);
            logger.info("onTestFailure: HTML збережено у файл " + fileName);
        } catch (IOException e) {
            logger.error("onTestFailure: Помилка при збереженні HTML", e);
        }

        // Виклик відеозапису (симуляція)
        simulateVideoRecording();
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        logger.warn("onTestSkipped: Тест " + result.getName() + " пропущено.");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // Не використовується у цьому прикладі
    }

    @Override
    public void onFinish(ITestContext context) {
        logger.info("onFinish(ITestContext): Завершення тестового контексту: " + context.getName());
    }

    // ISuiteListener методи

    @Override
    public void onStart(ISuite suite) {
        logger.info("onStart(ISuite): Запуск сьюту " + suite.getName());
    }

    @Override
    public void onFinish(ISuite suite) {
        logger.info("onFinish(ISuite): Завершення сьюту " + suite.getName());
    }

    // IExecutionListener методи

    @Override
    public void onExecutionStart() {
        logger.info("onExecutionStart: Початок виконання тестів.");
    }

    @Override
    public void onExecutionFinish() {
        logger.info("onExecutionFinish: Завершення виконання тестів.");
        // Приклад: DBLogger.logExecutionEnd(new Date());
    }

    // IInvokedMethodListener методи

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        logger.info("beforeInvocation: Перед викликом методу " + method.getTestMethod().getMethodName());
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        logger.info("afterInvocation: Завершено виклик методу " + method.getTestMethod().getMethodName());
        logger.info("afterInvocation: Закриття браузера, якщо це необхідно (логіка закриття).");
        // Наприклад, якщо використовуєте ThreadLocal WebDriver, закрийте його тут.
    }

    // Allure Attachments

    @Attachment(value = "Screenshot", type = "image/png")
    public byte[] saveScreenshotPNG(WebDriver driver) {
        logger.info("Allure Attachment: Збереження знімку екрану.");
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    @Attachment(value = "Page Source", type = "text/html")
    public String savePageSource(WebDriver driver) {
        logger.info("Allure Attachment: Збереження HTML сторінки.");
        return driver.getPageSource();
    }

    @Attachment(value = "Test Video", type = "video/mp4")
    public byte[] attachVideo(String filePath) throws IOException {
        logger.info("Allure Attachment: Прикріплення відеофайлу.");
        return Files.readAllBytes(Paths.get(filePath));
    }

    // Симуляція відеозапису (замініть цю частину на реальну інтеграцію з бібліотекою для відеозапису)
    private void simulateVideoRecording() {
        logger.info("simulateVideoRecording: Старт відеозапису невдалого тесту...");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        logger.info("simulateVideoRecording: Відеозапис завершено.");
    }
}
