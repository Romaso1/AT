package com.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.Assert;
import org.testng.annotations.*;

public class SomeSampleTest {
    WebDriver driver;

    @BeforeClass
    public void setUp(ITestContext context) {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        // Передаємо WebDriver у тестовий контекст для використання слухачем (наприклад, при невдачі)
        context.setAttribute("WebDriver", driver);
        driver.get("https://demoqa.com/radio-button");
    }

    @Test
    public void sampleTest() throws InterruptedException {
        // Проста перевірка, що заголовок містить "radio" (як приклад)
        String title = driver.getTitle();
        Assert.assertNotNull(title, "Title is null");
        Assert.assertTrue(title.length() > 0, "Title is empty");
        Thread.sleep(1000);
        // Якщо тест провалиться, слухач збере артефакти (знімок, сторінковий код).
        Assert.assertTrue(title.contains("NonExistentString"), "Цей тест навмисно провалюється для демонстрації Allure attachments");
    }

    @AfterClass
    public void tearDown() {
        if(driver != null) {
            driver.quit();
        }
    }
}
