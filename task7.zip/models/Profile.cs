﻿namespace SerializationProject.Models
{
    public class Profile
    {
        public int Id { get; set; }
        public string Bio { get; set; }
        public int HobbyistId { get; set; } // Зовнішній ключ для Hobbyist
        public Hobbyist Hobbyist { get; set; } // Зв'язок з Hobbyist
    }
}
