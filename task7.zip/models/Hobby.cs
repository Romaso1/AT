﻿using System.Collections.Generic;

namespace SerializationProject.Models
{
    public class Hobby
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int HobbyistId { get; set; }
        public Hobbyist Hobbyist { get; set; } // Зв'язок з Hobbyist
        public List<Tag> Tags { get; set; } = new List<Tag>(); // Зв'язок з Tag
    }
}
