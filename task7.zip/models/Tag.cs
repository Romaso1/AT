﻿using System.Collections.Generic;

namespace SerializationProject.Models
{
    public class Tag
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Hobby> Hobbies { get; set; } = new List<Hobby>(); // Зв'язок з Hobby
    }
}
