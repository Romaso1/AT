﻿using System.Collections.Generic;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SerializationProject.Models
{
    public class Hobbyist
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        // Зв'язок з Profile (One-to-One)
        public Profile Profile { get; set; }

        // Зв'язок з Hobby (One-to-Many)
        public List<Hobby> Hobbies { get; set; } = new List<Hobby>();
    }
}
