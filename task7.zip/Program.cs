﻿using System;
using System.Linq;
using SerializationProject.Data;
using SerializationProject.Models;

namespace SerializationProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // Створення бази даних та таблиць, якщо їх ще немає
            using (var context = new MyDatabaseContext())
            {
                context.Database.EnsureCreated();
            }

            // Виконання CRUD операцій
            using (var context = new MyDatabaseContext())
            {
                // Створення нового запису
                var hobbyist = new Hobbyist { Name = "Bob", Age = 30 };
                context.Hobbyists.Add(hobbyist);
                context.SaveChanges();

                // Додати профіль
                var profile = new Profile { Bio = "Loves hiking and painting", HobbyistId = hobbyist.Id };
                context.Profiles.Add(profile);
                context.SaveChanges();

                // Додати хобі
                var hobby1 = new Hobby { Name = "Hiking", HobbyistId = hobbyist.Id };
                var hobby2 = new Hobby { Name = "Painting", HobbyistId = hobbyist.Id };
                context.Hobbies.AddRange(hobby1, hobby2);
                context.SaveChanges();

                // Додати теги до хобі
                var tag1 = new Tag { Name = "Outdoors" };
                var tag2 = new Tag { Name = "Art" };

                hobby1.Tags.Add(tag1);
                hobby2.Tags.Add(tag2);
                context.SaveChanges();

                // Читання записів
                var hobbyists = context.Hobbyists.ToList();
                Console.WriteLine("Список хобістів:");
                foreach (var h in hobbyists)
                {
                    Console.WriteLine($"{h.Id}: {h.Name}, Вік: {h.Age}");

                    // Читати хобі та профілі
                    var profileForHobbyist = context.Profiles.FirstOrDefault(p => p.HobbyistId == h.Id);
                    if (profileForHobbyist != null)
                    {
                        Console.WriteLine($"    Профіль: {profileForHobbyist.Bio}");
                    }

                    var hobbies = context.Hobbies.Where(h => h.HobbyistId == h.Id).ToList();
                    foreach (var hobby in hobbies)
                    {
                        Console.WriteLine($"    Хобі: {hobby.Name}");
                        foreach (var tag in hobby.Tags)
                        {
                            Console.WriteLine($"        Тег: {tag.Name}");
                        }
                    }
                }

                // Оновлення запису
                hobbyist.Age = 31;
                context.SaveChanges();

                // Видалення запису
                context.Hobbies.Remove(hobby1);
                context.SaveChanges();
            }
        }
    }
}
