﻿using System;
using System.Linq;
using SerializationProject.Data;
using SerializationProject.Models;

namespace SerializationProject
{
    class Program
    {
        static void Main(string[] args)
        {
            // Створення бази даних та таблиць, якщо їх ще немає
            using (var context = new MyDatabaseContext())
            {
                context.Database.EnsureCreated();
            }

            // Виконання CRUD операцій
            using (var context = new MyDatabaseContext())
            {
                // Створення нового запису
                var hobbyist = new Hobbyist { Name = "Bob", Age = 30 };
                context.Hobbyists.Add(hobbyist);
                context.SaveChanges();

                // Читання записів
                var hobbyists = context.Hobbyists.ToList();
                Console.WriteLine("Список хобістів:");
                foreach (var h in hobbyists)
                {
                    Console.WriteLine($"{h.Id}: {h.Name}, Вік: {h.Age}");
                }

                // Оновлення запису
                hobbyist.Age = 31;
                context.SaveChanges();

                // Видалення запису
                context.Hobbyists.Remove(hobbyist);
                context.SaveChanges();
            }

            // Генерація кількох записів у таблиці
            //using (var context = new MyDatabaseContext())
            //{
            //    for (int i = 0; i < 5; i++)
            //    {
            //        var hobbyist = new Hobbyist { Name = $"Hobbyist {i}", Age = 20 + i };
            //        context.Hobbyists.Add(hobbyist);
            //    }

            //    context.SaveChanges();
            //}

            //Console.WriteLine("Записи успішно згенеровані.");
        }
    }
}
