﻿using Microsoft.EntityFrameworkCore;
using SerializationProject.Models;

namespace SerializationProject.Data
{
    public class MyDatabaseContext : DbContext
    {
        public DbSet<Hobbyist> Hobbyists { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL("Server=localhost;Database=my_database;User ID=root;Password=kill1234;Port=3306;"
);
        }
    }
}
