using System.Collections.Generic;

namespace PetProject.Utils
{
    public static class DataProvider
    {
        public static IEnumerable<object[]> LoginData()
        {
            yield return new object[] { "testuser1", "password1" };
            yield return new object[] { "testuser2", "password2" };
        }
    }
}
