using System;
using System.IO;

namespace PetProject.Utils
{
    public static class Logger
    {
        private static string logFilePath = "Logs/log.txt";

        public static void Log(string message)
        {
            File.AppendAllText(logFilePath, $"{DateTime.Now}: {message}\n");
        }

        public static void LogError(string message)
        {
            Log($"ERROR: {message}");
        }
    }
}
