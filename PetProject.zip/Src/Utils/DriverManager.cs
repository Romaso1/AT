using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;

namespace PetProject.Utils
{
    public class DriverManager
    {
        private static ThreadLocal<IWebDriver> driver = new ThreadLocal<IWebDriver>();

        public static IWebDriver GetDriver(string browser)
        {
            if (driver.Value == null)
            {
                switch (browser.ToLower())
                {
                    case "chrome":
                        driver.Value = new ChromeDriver();
                        break;
                    case "firefox":
                        driver.Value = new FirefoxDriver();
                        break;
                    default:
                        throw new ArgumentException("Unsupported browser: " + browser);
                }
            }
            return driver.Value;
        }

        public static void QuitDriver()
        {
            if (driver.Value != null)
            {
                driver.Value.Quit();
                driver.Value = null;
            }
        }
    }
}
