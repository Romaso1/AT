using PetProject.Ui.PageObjects;

namespace PetProject.Ui.BusinessObjects
{
    public class LoginBO
    {
        private LoginPage loginPage;

        public LoginBO(IWebDriver driver)
        {
            loginPage = new LoginPage(driver);
        }

        public void PerformLogin(string username, string password)
        {
            loginPage.Login(username, password);
        }
    }
}
