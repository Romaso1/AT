using NUnit.Framework;
using OpenQA.Selenium;
using PetProject.Ui.BusinessObjects;
using PetProject.Utils;

namespace PetProject.Ui.TestCases
{
    public class LoginTest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = DriverManager.GetDriver("chrome");
            driver.Navigate().GoToUrl("http://example.com/login");
        }

        [Test]
        public void TestLogin()
        {
            var loginBO = new LoginBO(driver);
            loginBO.PerformLogin("testuser", "password123");
            Assert.IsTrue(driver.Title.Contains("Dashboard"), "Login failed!");
        }

        [TearDown]
        public void TearDown()
        {
            DriverManager.QuitDriver();
        }
    }
}
