using NUnit.Framework;
using OpenQA.Selenium.Appium.Windows;

namespace PetProject.Desktop.TestCases
{
    public class DesktopAppTest
    {
        private WindowsDriver<WindowsElement> driver;

        [SetUp]
        public void Setup()
        {
            var options = new AppiumOptions();
            options.AddAdditionalCapability("app", "C:\\Path\\To\\YourApp.exe");
            options.AddAdditionalCapability("platformName", "Windows");

            driver = new WindowsDriver<WindowsElement>(new Uri("http://127.0.0.1:4723"), options);
        }

        [Test]
        public void TestCalculator()
        {
            driver.FindElementByName("1").Click();
            driver.FindElementByName("+").Click();
            driver.FindElementByName("2").Click();
            driver.FindElementByName("=").Click();
            Assert.AreEqual("3", driver.FindElementByAccessibilityId("CalculatorResults").Text);
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
