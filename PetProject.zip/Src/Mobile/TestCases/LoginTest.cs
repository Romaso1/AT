using NUnit.Framework;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using PetProject.Mobile.PageObjects;

namespace PetProject.Mobile.TestCases
{
    public class LoginTest
    {
        private AndroidDriver<AppiumWebElement> driver;

        [SetUp]
        public void Setup()
        {
            var options = new AppiumOptions();
            options.AddAdditionalCapability("platformName", "Android");
            options.AddAdditionalCapability("deviceName", "emulator-5554");
            options.AddAdditionalCapability("app", "path/to/app.apk");

            driver = new AndroidDriver<AppiumWebElement>(new Uri("http://localhost:4723/wd/hub"), options);
        }

        [Test]
        public void TestLogin()
        {
            var loginPage = new LoginPage(driver);
            loginPage.Login("testuser", "password123");
            Assert.IsTrue(driver.FindElementById("welcomeMessage").Displayed, "Login failed!");
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
