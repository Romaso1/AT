using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;

namespace PetProject.Mobile.PageObjects
{
    public class LoginPage
    {
        private AndroidDriver<AppiumWebElement> driver;

        public LoginPage(AndroidDriver<AppiumWebElement> driver)
        {
            this.driver = driver;
        }

        public void Login(string username, string password)
        {
            driver.FindElementById("username").SendKeys(username);
            driver.FindElementById("password").SendKeys(password);
            driver.FindElementById("loginButton").Click();
        }
    }
}
