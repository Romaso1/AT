using NUnit.Framework;
using RestSharp;
using PetProject.Api;

namespace PetProject.Api.TestCases
{
    public class LoginApiTest
    {
        private ApiClient apiClient;

        [SetUp]
        public void Setup()
        {
            apiClient = new ApiClient("http://example.com/api");
        }

        [Test]
        public void TestLogin()
        {
            var response = apiClient.SendRequest("/login", Method.POST, new { username = "testuser", password = "password123" });
            Assert.AreEqual(200, (int)response.StatusCode, "Login failed!");
        }
    }
}
