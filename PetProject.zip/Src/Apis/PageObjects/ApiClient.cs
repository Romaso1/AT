using RestSharp;

namespace PetProject.Api
{
    public class ApiClient
    {
        private readonly RestClient client;

        public ApiClient(string baseUrl)
        {
            client = new RestClient(baseUrl);
        }

        public RestResponse SendRequest(string endpoint, Method method, object body = null)
        {
            var request = new RestRequest(endpoint, method);
            if (body != null)
                request.AddJsonBody(body);

            return client.Execute(request);
        }
    }
}
