﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

[TestFixture]
public class SignUpTests
{
    private IWebDriver driver;
    private const string baseUrl = "https://www.demoblaze.com/";

    [SetUp]
    public void SetUp()
    {
        driver = new ChromeDriver();
        driver.Navigate().GoToUrl(baseUrl);
        driver.Manage().Window.Maximize();
    }

    [TearDown]
    public void TearDown()
    {
        if (driver != null)
        {
            driver.Quit();
            driver.Dispose();
        }
    }

    [Test]
    public void TestUserCanSignUpAndLogin()
    {
        string uniqueUsername = "testuser" + DateTime.Now.Ticks;

        // Перейдіть на сторінку реєстрації
        var signUpPage = new SignUpPage(driver);
        signUpPage.ClickSignUpButtonHome();

        // Введіть дані користувача
        signUpPage.EnterUsername(uniqueUsername); // Додано унікальність імені користувача для уникнення конфліктів
        signUpPage.EnterPassword("StrongPassword123!");

        // Натисніть кнопку "Зареєструватися"
        signUpPage.ClickSignUp();

        // Прийняти спливаюче вікно
        signUpPage.AcceptAlert();

        // Логін після реєстрації
        var loginPage = new LoginPage(driver);
        loginPage.ClickLoginButtonHome();
        loginPage.EnterUsername(uniqueUsername);
        loginPage.EnterPassword("StrongPassword123!");
        loginPage.ClickLogin();

        // Зачекаємо трохи, щоб завершилася авторизація і відбулося перенаправлення
        System.Threading.Thread.Sleep(3000); // Ви можете використовувати WebDriverWait для кращої практики

        var homePage = new HomePage(driver);

        // Перевірка, що користувач увійшов в систему
        bool isLoggedIn = homePage.IsUserLoggedIn();
        Assert.IsTrue(isLoggedIn, "User should be logged in.");
    }
}
