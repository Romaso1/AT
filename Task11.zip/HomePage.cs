﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;

public class HomePage
{
    private IWebDriver driver;
    private WebDriverWait wait;

    private By loggedInUserElement = By.Id("nameofuser"); // Елемент, що відображає ім'я користувача після входу

    public HomePage(IWebDriver driver)
    {
        this.driver = driver;
        wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
    }

    public bool IsUserLoggedIn()
    {
        try
        {
            wait.Until(ExpectedConditions.ElementIsVisible(loggedInUserElement));
            return driver.FindElement(loggedInUserElement).Displayed;
        }
        catch (NoSuchElementException)
        {
            return false;
        }
        catch (WebDriverTimeoutException)
        {
            return false;
        }
    }
}
