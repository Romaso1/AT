﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;

public class LoginPage
{
    private IWebDriver driver;
    private WebDriverWait wait;

    private By loginButtonHome = By.Id("login2"); // Кнопка "Log in" на головній сторінці
    private By usernameField = By.Id("loginusername"); // Поле для введення ім'я користувача
    private By passwordField = By.Id("loginpassword"); // Поле для введення паролю
    private By loginButton = By.XPath("//button[text()='Log in']"); // Кнопка логіну

    public LoginPage(IWebDriver driver)
    {
        this.driver = driver;
        wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
    }

    public void ClickLoginButtonHome()
    {
        driver.FindElement(loginButtonHome).Click();
    }

    public void EnterUsername(string username)
    {
        wait.Until(ExpectedConditions.ElementIsVisible(usernameField));
        driver.FindElement(usernameField).SendKeys(username);
    }

    public void EnterPassword(string password)
    {
        wait.Until(ExpectedConditions.ElementIsVisible(passwordField));
        driver.FindElement(passwordField).SendKeys(password);
    }

    public void ClickLogin()
    {
        wait.Until(ExpectedConditions.ElementToBeClickable(loginButton));
        driver.FindElement(loginButton).Click();
    }
}
